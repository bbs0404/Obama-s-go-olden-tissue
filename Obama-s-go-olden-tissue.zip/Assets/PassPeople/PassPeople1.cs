﻿using UnityEngine;
using System.Collections;

public class PassPeople1 : PassPeople {

	// Use this for initialization
	void Start () {
        IsTissueReceived = false;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
